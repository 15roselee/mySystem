module.exports = {
    singleQuote: true,
    trailingComma: 'es5',
    arrowParens: 'avoid',
    proseWrap: 'always',
  };